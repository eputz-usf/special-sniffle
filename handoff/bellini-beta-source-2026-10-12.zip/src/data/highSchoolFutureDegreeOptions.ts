export type HighSchoolFutureDegreeOption = {
  slug: string;
  name: string;
  focus: string;
  cardDescription: string;
  cardBestFor: string;
  description: string;
  goodFit: string;
  planningResources: {
    label: string;
    url: string;
  }[];
  programUrl: string;
  status: string;
};

export const plannedHighSchoolFutureDegreeOptions = [
  {
    slug: 'computer-science-and-criminology',
    cardBestFor: 'Cybercrime, digital investigations, public safety',
    cardDescription: 'Combines computing with criminology to explore technology, crime, and justice.',
    name: 'BS in Computer Science and Criminology',
    focus: 'Computing + Criminology + Cybercrime',
    description:
      'This major combines computer science with crime, justice, and public safety. Students learn how technology can be used to understand cybercrime, digital evidence, cybersecurity, and justice systems.',
    goodFit:
      'Cybercrime, digital investigations, cybersecurity, public safety, justice systems, or solving real-world crime and security problems with technology.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/h4zaqcaf6192e1kof8sjmnc8j5ojf8b1',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/oarwgaex45jq7jlqlkalvx1tpid9yp0t',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=14013&returnto=5248',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-interdisciplinary-social-sciences',
    cardBestFor: 'Technology and society, community data, social impact',
    cardDescription: 'Combines computing with social sciences to explore people, communities, and public systems.',
    name: 'BS in Computer Science and Interdisciplinary Social Sciences',
    focus: 'Computing + Social Sciences + People',
    description:
      'This major combines computer science with social science topics. Students choose a focus area and take electives related to people, communities, society, or public systems.',
    goodFit:
      'Technology and society, human-centered computing, civic technology, social impact, community data, policy, research, or public service.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/hvwyxa9ijszxndq4zzftj9d4x1wtm1r5',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/35ovjdf515yhpzh00yu6u459thdamboj',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=14014',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-business-accountancy-and-analytics',
    cardBestFor: 'Accounting technology, financial data, auditing',
    cardDescription: 'Connects computing with accounting and analytics for financial systems and reporting.',
    name: 'BS in Computer Science and Business: Accountancy and Analytics Concentration',
    focus: 'Computing + Accounting + Analytics',
    description:
      'This concentration combines computer science with accounting and data analysis. Students learn how technology can support financial data, accounting systems, auditing, and business reports.',
    goodFit:
      'Accounting technology, financial data, analytics, auditing systems, business reports, or using technology to help with financial decisions.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/82wezpx5wzi3y19an4freplz25fh83wl',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/a3v5qtks4p76vmlqwhe4z18ru6w8e61e',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=14015&returnto=5248',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-business-analytics-and-information-systems',
    cardBestFor: 'Business data, information systems, technology consulting',
    cardDescription: 'Connects computing with business analytics and information systems to support decisions and operations.',
    name: 'BS in Computer Science and Business: Business Analytics and Information Systems Concentration',
    focus: 'Computing + Business Analytics + Information Systems',
    description:
      'This concentration combines computer science with business data and technology systems. Students learn how computing can help businesses make better decisions and improve operations.',
    goodFit:
      'Business data, information systems, dashboards, databases, systems analysis, business technology, or technology consulting.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/tqrkhr3t9h5hvzmeus1yn4ary20mmu9t',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/aewcolvy39s2lgpfarp4e1d2zdn3jct2',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=16474&returnto=5248',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-business-digital-marketing-and-analytics',
    cardBestFor: 'Digital marketing, customer data, web analytics',
    cardDescription: 'Connects computing with digital marketing and analytics to understand customers and campaigns.',
    name: 'BS in Computer Science and Business: Digital Marketing and Analytics Concentration',
    focus: 'Computing + Digital Marketing + Analytics',
    description:
      'This concentration combines computer science with digital marketing and data analysis. Students learn how technology can help understand customers, online behavior, campaigns, and digital platforms.',
    goodFit:
      'Digital marketing, customer data, web analytics, social media data, advertising technology, product growth, or marketing technology tools.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/4c6czbk3gum95tcs9dog3yh3jvcrt4yv',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/ozdzm16qmk014e074q13zqy4lfp3q7u8',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=16475&returnto=5248',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-business-fintech',
    cardBestFor: 'Financial apps, payments, banking technology',
    cardDescription: 'Connects computing with finance to explore technology in banking, payments, and financial services.',
    name: 'BS in Computer Science and Business: Fintech Concentration',
    focus: 'Computing + Finance + Financial Technology',
    description:
      'This concentration combines computer science with finance. Students learn how software, data, cybersecurity, and automation are used in banking, payments, investing, and financial services.',
    goodFit:
      'Fintech, banking technology, financial apps, payments, financial data, risk technology, or secure financial platforms.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/9jcps8zlpwnsdoqk75caudb3d31stu8e',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/xeasr561c85wxix0he7q5dyv03qwxg5s',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=16476&returnto=5248',
    status: 'Coming soon',
  },
  {
    slug: 'computer-science-and-business-supply-chain-management',
    cardBestFor: 'Logistics, inventory systems, operations data',
    cardDescription: 'Connects computing with supply chain management to improve logistics and business operations.',
    name: 'BS in Computer Science and Business: Supply Chain Management Concentration',
    focus: 'Computing + Supply Chain + Operations',
    description:
      'This concentration combines computer science with supply chain and operations. Students learn how technology and data can improve logistics, inventory, transportation, and business processes.',
    goodFit:
      'Supply chain technology, logistics systems, operations data, inventory tools, transportation systems, process improvement, or data-driven operations.',
    planningResources: [
      {
        label: '2-Year Plan of Study',
        url: 'https://usf.box.com/s/ire2lmvxupjcntf2tvcote2sxl92bvso',
      },
      {
        label: '4-Year Plan of Study',
        url: 'https://usf.box.com/s/jsfy92z2bno3p7qohq9ingp33qjj2u5q',
      },
    ],
    programUrl:
      'https://catalog.usf.edu/preview_program.php?catoid=25&poid=16477&returnto=5248',
    status: 'Coming soon',
  },
] satisfies HighSchoolFutureDegreeOption[];

export function getHighSchoolFutureDegreeOptionBySlug(slug: string | undefined) {
  return plannedHighSchoolFutureDegreeOptions.find(
    (degree) => degree.slug === slug,
  );
}


export const interdisciplinaryDegrees = plannedHighSchoolFutureDegreeOptions.map((option) => ({
  slug: option.slug,
  name: option.name,
  credential: 'BS',
  category: 'Interdisciplinary' as const,
  bestFor: option.cardBestFor,
  description: option.cardDescription,
  skills: 'Program-specific skills pending academic review.',
  overview: option.description,
  goodFit: [option.goodFit],
  sampleTopics: ['Coursework details pending academic review.'],
  nextSteps: ['Confirm admissions status, catalog year, requirements, and electives with Bellini advising.'],
  officialLinks: { plans: option.planningResources },
  status: option.status,
}));
